$(function() {
    "use strict";

 

		
		
   });	 
   