let table = document.querySelector("#table_body")
let india_map = document.querySelector("#india_map")

india_map.addEventListener("click",handleMapInteraction)





function handleMapInteraction(e){
    let target = e.target
    if(target.tagName !== "path")
    return

    let state = encodeURI(target.id)

    let url = window.location.origin
    window.location.assign(url+`/getStateData?state=${state}`)

}



table.addEventListener("click",(e)=>{
    let target = e.target
    if(e.target.tagName == "TD"){
       target = target.parentElement
    }
    let state = target.dataset.location
    let url = window.location.origin
    window.location.assign(url+`/getStateData?state=${state}`)
})

function generateRandomColor(){
    return ('#'+Math.floor(Math.random()*16777215).toString(16));
}


let myChart

function renderChart(states,stats){
    let randomColors = []
    let data = []
    for(let i=0;i<states.length;i++){
        randomColors.push(generateRandomColor())
        let state_data = stats[`${states[i]}`]
        data.push(state_data)
    }

    var ctx = document.getElementById("chart").getContext('2d');
     myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: states,
            datasets: [{
                backgroundColor:randomColors,
                data: data,
                borderWidth: [0, 0, 0, 0]
            }]
        },
    options: {
        maintainAspectRatio: false,
       legend: {
         position :"top",	
         display: true,
         onClick:renderState,
            labels: {
              fontColor: '#ddd',  
              boxWidth:15
           }
        }
        ,
        tooltips: {
          displayColors:true
        }
       }
    });
}

function renderState(e,item){

    console.log(item.text)
    let url = window.location.origin
    let state = item.text
    window.location.assign(url+`/getStateData?state=${state}`)
}




document.getElementById("chart").onclick = function(evt){
    var activePoints = myChart.getElementsAtEvent(evt);
    var firstPoint = activePoints[0];
    if(activePoints.length ==0)
    return
    var label = myChart.data.labels[firstPoint._index];
  
   
    let url = window.location.origin;
    let state = encodeURI(label)


    window.location.assign(url+`/getStateData?state=${state}`)
    
};



function renderCoursesChart(data_courses){

    let courses = Object.keys(data_courses)
    let randomColors = []

    

    let data = []
    for(let i=0;i<courses.length;i++){
        randomColors.push(generateRandomColor())
        let course_data = data_courses[`${courses[i]}`]
        data.push(course_data)
    }


    var ctx = document.getElementById("chart2").getContext('2d');
     myChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: courses,
            datasets: [{
                backgroundColor:randomColors,
                data: data,
                borderWidth: [0, 0, 0, 0]
            }]
        },
    options: {
        maintainAspectRatio: false,
       legend: {
         position :"top",	
         display: true,
       
            labels: {
              fontColor: '#ddd',  
              boxWidth:15
           }
        }
        ,
        tooltips: {
          displayColors:true
        }
       }
    });
}


async function generateStatesChart(){
    let url = window.location.origin
    let data = await fetch(url +"/data",{method:"GET"})
    data = await data.json()
    renderChart(data.states,data.stats)
}


async function generateCourses(){
    let url = window.location.origin
    let data = await fetch(url +"/get-courses-data",{method:"GET"})
    data = await data.json()

    renderCoursesChart(data)
}


 generateCourses()
 generateStatesChart()
